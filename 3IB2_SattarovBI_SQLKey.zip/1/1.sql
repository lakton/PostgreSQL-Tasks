------------1st task.

\echo Creating the 'sattarov_db' database;
CREATE DATABASE sattarov_db;

\echo Connecting to the 'sattarov_db' database;
\c sattarov_db;

\echo Creating the customers table with primary key constraint;
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL
);

\echo Creating the orders table with foreign key constraint;
CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    item TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price NUMERIC(10,2) NOT NULL
);

\echo Inserting data into the customers table;
INSERT INTO customers (name, email, phone) VALUES 
    ('Bulat Sattarov', 'sattarovbi20@st.ithub.ru', '555-555-5555'), 
    ('Ivan Ivanov', 'ivanovii00@st.ithub.ru', '555-555-5556');

\echo Inserting data into the orders table;
INSERT INTO orders (customer_id, item, quantity, price) VALUES
    (1, 'item1', 10, 20.50),
    (1, 'item2', 5, 15.99),
    (2, 'item3', 2, 9.99);

\echo Creating a rule for checking metadata on parameters;
CREATE RULE check_metadata AS
    ON INSERT TO orders
    WHERE new.quantity < 0 OR new.price < 0
    DO INSTEAD NOTHING;
CREATE RULE myrule AS ON INSERT TO customers
    WHERE (NEW.name = 'Bulat Sattarov' AND NEW.email = 'sattarovbi20@st.ithub.ru')
    DO INSTEAD NOTHING;