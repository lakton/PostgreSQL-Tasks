------------3rd task.

\c sattarov_db;
\echo  !!! Recommend to execute this commands manually,  !!!;
\echo  !!! because .SQL script can not open 2nd terminal and execute commands like that !!!;


\echo Starting a transaction in console 1;
BEGIN;

\echo Updating phone number for customer 'Bulat Sattarov' in console 1;
UPDATE customers SET phone = '555-555-5558' WHERE name = 'Bulat Sattarov';

\echo Checking for changes in console 2;
SELECT * FROM customers;

\echo Rolling back changes in console 1;
ROLLBACK;

\echo Starting a transaction in console 1;
BEGIN;

\echo Updating phone number for customer 'Bulat Sattarov' in console 1;
UPDATE customers SET phone = '555-555-5558' WHERE name = 'Bulat Sattarov';

\echo Checking for changes in console 2;
SELECT * FROM customers;

\echo Committing changes in console 1;
COMMIT;

\echo Checking for changes in console 2;
SELECT * FROM customers;