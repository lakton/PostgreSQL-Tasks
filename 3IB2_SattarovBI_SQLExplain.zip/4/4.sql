\echo  Query that uses the EXPLAIN;
EXPLAIN SELECT * FROM customers WHERE name = 'Bulat Sattarov';

\echo  More complex query that uses a join and a nested query;
EXPLAIN SELECT c.name, o.item, o.quantity 
FROM customers c 
JOIN orders o 
ON c.id = o.customer_id 
WHERE c.id IN (SELECT id FROM customers WHERE name LIKE '%Ivan%');

\echo  Execute multiple queries by separating them with semicolons;
EXPLAIN SELECT * FROM customers WHERE name = 'Bulat Sattarov';
EXPLAIN SELECT c.name, o.item, o.quantity FROM customers c JOIN orders o ON c.id = o.customer_id WHERE c.id IN (SELECT id FROM customers WHERE name LIKE '%Ivan%');

