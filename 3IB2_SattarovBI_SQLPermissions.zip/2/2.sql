------------2nd task.
\c sattarov_db;
\echo Creating the 'sattarovbi_admin' role;
CREATE ROLE sattarovbi_admin;

\echo Granting SELECT privileges on the customers and orders tables to the 'sattarovbi_admin' role;
GRANT SELECT ON TABLE customers TO sattarovbi_admin;
GRANT SELECT ON TABLE orders TO sattarovbi_admin;

\echo Revoking INSERT privileges on the customers and orders tables from the 'sattarovbi_admin' role;
REVOKE INSERT ON TABLE customers FROM sattarovbi_admin;
REVOKE INSERT ON TABLE orders FROM sattarovbi_admin;

\echo Testing SELECT using the 'sattarovbi_admin' role;
SET ROLE sattarovbi_admin;
SELECT * FROM customers;

\echo Testing INSERT using the 'sattarovbi_admin' role;
INSERT INTO customers (name, email, phone) VALUES ('Bulat Sattarov', 'sattarovbi20@st.ithub.ru', '555-555-5557');

\echo Revoking all privileges granted to the role;
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM sattarovbi_admin;

\echo Deleting the 'sattarovbi_admin' role;
DROP ROLE sattarovbi_admin;